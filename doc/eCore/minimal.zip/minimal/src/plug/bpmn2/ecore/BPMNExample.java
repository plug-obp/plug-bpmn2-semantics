package plug.bpmn2.ecore;

public class BPMNExample {

    public static void main(String[] args) {
        BPMNeCoreLoader loader = new BPMNeCoreLoader();
        loader.loadModelFromURLString(args[0]);
        new BPMNModelPrinter().getString(loader.getDocumentRoot());
    }
}
